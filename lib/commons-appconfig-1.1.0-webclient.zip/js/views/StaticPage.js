define([
    '../models/Model',
    '../views/partials/Link',
    'jquery',
    'underscore',
    'backbone'
], function(ApplicationConfigurationModel, ApplicationConfigurationLinkView, $, _, Backbone){
    
    /*
     * This is the entry point for the views.  This class will fetch the data, iterate through it
     * and call the ItemView for each record.
     */ 
    return Backbone.View.extend({

        initialize: function(options){
            this.groupName = options.groupName;

            this.setElement($("#applicationConfigurationDetail"));

            this.render();
        },
        
        // Create views based on group names 
        createAndRenderGroup: function(){
            switch(this.groupName){
                case "data_exchange":
                    importModel = new ApplicationConfigurationModel();
                    importModel.set({
                        "value": "true",
                        "linkId": "importItemsLink",
                        "link": "../importTask/list",
                        "linkText": "<h5>Import Listings</h5>Import listings into your store by clicking here."
                    });
                    linkView = new ApplicationConfigurationLinkView({model:importModel});
                    linkView.render();
                    this.$el.append(linkView.el);
                    
                    exportModel = new ApplicationConfigurationModel();
                    exportModel.set({
                        "value": "true",
                        "linkId": "exportItemsLink",
                        "link": "../public/exportAll",
                        "linkText": "<h5>Export Listings</h5>Export your data for use in another store by clicking here."
                    });
                    linkView = new ApplicationConfigurationLinkView({model:exportModel});
                    linkView.render();
                    this.$el.append(linkView.el);
                    break;
                    
                case "listing_management":
                    listingModel = new ApplicationConfigurationModel();
                    listingModel.set({
                        "value": "true",
                        "linkId": "pendingListingsLink",
                        "link": "../serviceItem/adminView?sort=editedDate&order=desc&accessType=Administrator",
                        "linkText": "<h5>Pending Listings</h5>View your pending listings by clicking here."
                    });
                    linkView = new ApplicationConfigurationLinkView({model:listingModel});
                    linkView.render();
                    this.$el.append(linkView.el);
                    break;
            }
        },

        render: function(){
            this.$el.empty().append("<br>");
            this.createAndRenderGroup();
        }
    });
});
