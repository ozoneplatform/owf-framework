define([
    '../collections/Collection',
    '../collections/Errors',
    '../views/Item',
    'jquery',
    'underscore',
    'backbone'
], function(ApplicationConfigurationCollection, ApplicationConfigurationErrors, ApplicationConfigurationItemView, $, _, Backbone){
  
    /*
    * This is the entry point for the views.  This class will fetch the data, iterate through it
    * and call the ItemView for each record.
    */ 
    return Backbone.View.extend({

        initialize: function(options){
            _.bindAll(this, "renderItem");
          
            this.collection = new ApplicationConfigurationCollection();

            this.setElement($("#applicationConfigurationDetail"));
        },

        fetchAndRender: function () {
            var me = this,
                groupName = (me.options && me.options.groupName) || '',
                params = {
                    data: $.param({
                        groupName: groupName
                    })
                };

            me.collection.fetch(params).complete(function(){
                me.render();
            });
        },

        needToRender: function(model) {
            var modelCode = model.get("code");
            
            switch (modelCode) {
                case "store.valid.domains": return false;
                case "store.domains": return false;
                
                case "store.is.franchise":
                    if(!model.get("mutable")) {
                        return false;
                    }
            }

            return true;
        },

        renderItem: function(model){
            var itemView = new ApplicationConfigurationItemView({
                model:model
            });

            if (this.needToRender(model)) {
                itemView.render();
                this.$el.append(itemView.el);
            }
        },

        render: function(){
            this.$el.empty().append("<br>");
            this.collection.each(this.renderItem);
        }
    });
});
